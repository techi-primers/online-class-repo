package class2;

public class demo_7_8 {

    public static void main(String[] args) {

        // create a method
        // pass int val1, int val2, String operation
        // return type Integer
        // inside the moethod process base on the operation need to do the mathematical operatin

        // if conditions
        // local variables



    }




}
